"""Cloud ASGI entrypoint with bearer-token protection around read-only MCP tools."""
import hmac
import os
from starlette.responses import JSONResponse
from server import mcp

mcp_app = mcp.streamable_http_app()

class ProtectedApp:
    def __init__(self, downstream):
        self.downstream = downstream

    async def __call__(self, scope, receive, send):
        if scope['type'] == 'lifespan':
            await self.downstream(scope, receive, send)
            return
        if scope['type'] != 'http':
            await self.downstream(scope, receive, send)
            return
        if scope.get('path') == '/health':
            await JSONResponse({'status': 'ok', 'service': 'mstr-read-only-market-data'})(scope, receive, send)
            return
        token = os.environ.get('MCP_ACCESS_TOKEN', '')
        if not token or len(token) < 32:
            await JSONResponse({'error': 'MCP_ACCESS_TOKEN not configured'}, status_code=503)(scope, receive, send)
            return
        headers = dict(scope.get('headers', []))
        supplied = headers.get(b'authorization', b'').decode('utf-8', 'replace')
        expected = 'Bearer ' + token
        if not hmac.compare_digest(supplied, expected):
            await JSONResponse({'error': 'unauthorized'}, status_code=401,
              headers={'WWW-Authenticate': 'Bearer'})(scope, receive, send)
            return
        await self.downstream(scope, receive, send)

app = ProtectedApp(mcp_app)
