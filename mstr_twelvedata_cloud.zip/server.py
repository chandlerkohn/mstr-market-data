"""Read-only Twelve Data MCP server. Never place trades or expose API keys."""
import json
import os
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("MSTR Market Data", host="127.0.0.1", port=8000)
NY = ZoneInfo("America/New_York")
SYMBOLS = {"MSTR", "QQQ", "BTC/USD"}


def fetch(endpoint: str, **params):
    key = os.environ.get("TWELVEDATA_API_KEY")
    if not key:
        raise RuntimeError("TWELVEDATA_API_KEY is missing from the server environment")
    params["apikey"] = key
    url = "https://api.twelvedata.com/" + endpoint + "?" + urllib.parse.urlencode(params)
    request = urllib.request.Request(url, headers={"User-Agent": "MSTR-ReadOnly-Connector/1.0"})
    with urllib.request.urlopen(request, timeout=12) as response:
        result = json.load(response)
    if result.get("status") == "error" or result.get("code"):
        raise RuntimeError(f"Twelve Data error: {result.get('message', 'unknown')} [code={result.get('code', '')}]")
    return result


def parse_quote_time(payload):
    # Only use market-data time explicitly returned by provider, never current retrieval time.
    if payload.get("timestamp") is not None:
        return datetime.fromtimestamp(int(payload["timestamp"]), tz=timezone.utc)
    raw = payload.get("datetime")
    if not raw:
        return None
    dt = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    return dt.replace(tzinfo=NY) if dt.tzinfo is None else dt


def validated_quote(symbol: str, max_age_seconds=60):
    if symbol not in SYMBOLS:
        raise ValueError("Allowed symbols: MSTR, QQQ, BTC/USD")
    start = datetime.now(timezone.utc)
    payload = fetch("quote", symbol=symbol, prepost="false")
    retrieved = datetime.now(timezone.utc)
    market_time = parse_quote_time(payload)
    age = None if market_time is None else (retrieved-market_time).total_seconds()
    acceptable = age is not None and -10 <= age <= max_age_seconds
    return {
        "symbol": symbol,
        "source": "Twelve Data /quote",
        "price": payload.get("close"),
        "market_data_timestamp_utc": market_time.astimezone(timezone.utc).isoformat() if market_time else None,
        "market_data_timestamp_et": market_time.astimezone(NY).isoformat() if market_time else None,
        "retrieval_started_utc": start.isoformat(),
        "retrieved_utc": retrieved.isoformat(),
        "age_seconds": round(age, 1) if age is not None else None,
        "fresh_under_60_seconds": acceptable,
        "session": "extended" if payload.get("is_extended_hours") else "regular_or_unspecified",
        "provider_extended_hours_flag": payload.get("is_extended_hours"),
        "data_quality": "FRESH" if acceptable else "STALE_OR_UNVERIFIABLE",
        "note": "No actionable entry if stale. A fresh provider quote does not guarantee a consolidated SIP trade.",
    }


@mcp.tool()
def get_quotes() -> dict:
    """Fetch timestamped MSTR, QQQ and BTC/USD public quotes; reject stale observations."""
    results = {}
    for symbol in ("MSTR", "QQQ", "BTC/USD"):
        try:
            results[symbol] = validated_quote(symbol)
        except Exception as exc:
            results[symbol] = {"data_quality": "UNAVAILABLE", "error": str(exc)}
    return {"quotes": results, "trade_permission": "REQUIRES_FRESH_MSTR_AND_CANDLE_CONFIRMATION"}


@mcp.tool()
def get_mstr_five_minute_candles() -> dict:
    """Return five-minute MSTR candles and session VWAP only when valid regular-hours volume exists."""
    retrieved = datetime.now(timezone.utc)
    try:
        payload = fetch("time_series", symbol="MSTR", interval="5min", outputsize=100, timezone="America/New_York", prepost="false")
        rows = payload.get("values", [])
        today = retrieved.astimezone(NY).date()
        session = []
        for row in rows:
            dt = datetime.fromisoformat(row["datetime"])
            if dt.date() != today or not (9 <= dt.hour <= 16):
                continue
            # Regular session: 09:30 through 15:55 bar starts.
            minute = dt.hour * 60 + dt.minute
            if not (570 <= minute < 960):
                continue
            session.append(row)
        session.reverse()
        cum_pv = 0.0
        cum_volume = 0.0
        for row in session:
            try:
                high, low, close = (float(row[k]) for k in ("high", "low", "close"))
                volume = float(row["volume"])
            except (KeyError, TypeError, ValueError):
                continue
            if volume <= 0:
                continue
            cum_pv += ((high + low + close) / 3) * volume
            cum_volume += volume
        return {
            "source": "Twelve Data /time_series",
            "retrieved_utc": retrieved.isoformat(),
            "interval": "5min",
            "session_date_et": str(today),
            "regular_session_candles": session,
            "vwap_estimate_typical_price": round(cum_pv / cum_volume, 4) if cum_volume else None,
            "vwap_note": "Typical-price five-minute candle VWAP approximation; not tick-exact VWAP. Missing or delayed volume invalidates this calculation.",
            "candle_count": len(session),
            "quality": "NOT_AVAILABLE" if not session else "CANDLES_AVAILABLE_CHECK_LAST_BAR_AND_QUOTE_FRESHNESS",
            "warning": "Do not trade unless latest MSTR quote is <=60 seconds old, market session confirmed, and candle timestamps/volume are appropriate.",
        }
    except Exception as exc:
        return {"quality": "UNAVAILABLE", "error": str(exc), "retrieved_utc": retrieved.isoformat()}


if __name__ == "__main__":
    mcp.run(transport="streamable-http")
